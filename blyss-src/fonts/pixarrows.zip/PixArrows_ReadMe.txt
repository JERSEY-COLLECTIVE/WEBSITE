Hi, thanx for downloading PixArrows !
If you plan to use it for commercial purpose, please drop me a line at daaams[AT]laposte.net !
I can add Lowercase characters and Alternates to the font.

You can use it for free for your personnal use only, and you can make any donation on paypal to daaams[AT]laposte.net (and don't hesitate to send me samples of your work, made with this font). 

You're not authorized to modify or sell this font.
Please always keep this Read_me file with the font.

daaams[AT]laposte.net  |  http://www.sweeep.fr

-----------------------------------------------------------------------------------------------------

Merci d'avoir t�l�charg� PixArrows !
Si vous voulez vous en servir � des fins commerciales, merci de me contacter par mail � daaams[AT]laposte.net !
Je peux ajouter les bas de casse (caract�res minuscules) et des caract�res alternatifs � la police.

Vous pouvez l'utiliser gratuitement � but personnel uniquement et vous pouvez toutefois me faire un don � daaams[AT]laposte.net ! (n'h�sitez pas � m'envoyer vos boulots faits avec ma police, �a m'interesse !).

Vous n'avez pas le droit de modifier ni de vendre cette police.
Merci de toujours laisser ce fichier Read_Me avec la police.

daaams[AT]laposte.net  |  http://www.sweeep.fr